num1 = 10
num2 = 0
nums = [1, 3, 5, 7, 9]
try:
    print("output")
    print(num1 * num2)
    print(num1 / (num2))
    print(nums[100])
except:
    print("產生例外")
print('程式結束')
