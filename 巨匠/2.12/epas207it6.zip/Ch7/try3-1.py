num1 = 10
num2 = 0
nums = [1,3,5,7,9]
try:
    #print(num1/num2)
    #print(num1*num3)
    print(nums[100])
except ZeroDivisionError:
    print('Error發生，除以0')
except (NameError,IndexError):
    print('NameError或IndexErrorError發生')
