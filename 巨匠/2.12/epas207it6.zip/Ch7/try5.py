num1 = 10
num2 = 0
nums = [1,3,5,7,9]
try:
    print(num1/(num2+1))
    print(num1*num2)
except:
    print('Error發生')
else:    
    print(nums[100])
    print('Error沒發生')
